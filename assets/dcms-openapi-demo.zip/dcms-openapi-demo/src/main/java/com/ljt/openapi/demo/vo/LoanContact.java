package com.ljt.openapi.demo.vo;


public class LoanContact {
  /**
   * 联系人姓名
   */
  private java.lang.String nm;
  /**
   * 联系人电话号
   */
  private java.lang.String mobileNo;
  /**
   * 联系人邮箱
   */
  private java.lang.String email;
  /**
   * 联系人关系
   */
  private java.lang.String mtCifContactCd;
  /**
   * 联系人职位
   */
  private java.lang.String mtPosHeldCd;

  public java.lang.String getNm() {
    return nm;
  }

  public void setNm(java.lang.String nm) {
    this.nm = nm;
  }

  public java.lang.String getMobileNo() {
    return mobileNo;
  }

  public void setMobileNo(java.lang.String mobileNo) {
    this.mobileNo = mobileNo;
  }

  public java.lang.String getEmail() {
    return email;
  }

  public void setEmail(java.lang.String email) {
    this.email = email;
  }

  public java.lang.String getMtCifContactCd() {
    return mtCifContactCd;
  }

  public void setMtCifContactCd(java.lang.String mtCifContactCd) {
    this.mtCifContactCd = mtCifContactCd;
  }

  public java.lang.String getMtPosHeldCd() {
    return mtPosHeldCd;
  }

  public void setMtPosHeldCd(java.lang.String mtPosHeldCd) {
    this.mtPosHeldCd = mtPosHeldCd;
  }

}

